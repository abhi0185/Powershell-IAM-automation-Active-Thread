<#
$a = "<style>"
$a = $a + '<img src="C:\Users\605819\Desktop\ActiveThread\image1.jpg" alt="HTML5 Icon" style="width:32px;height:32px;">'
$a = $a + "</style>"

$Header1 = @"
<Title>Service Uptime Status Report</Title>
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;display: inline-block; float: left;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
<img src="C:\Users\605819\Desktop\ActiveThread\image1.jpg" alt="HTML5 Icon" style="width:320px;height:320px;">
</style>
<Body>
<img src="C:\Users\605819\Desktop\ActiveThread\image1.jpg" alt="HTML5 Icon">
</Body>
"@

ConvertTo-HTML -head $Header1 | 
        Out-File C:\Users\605819\Desktop\ActiveThread\monitoring.htm 
#>

$HTML_Path = 'C:\Users\605819\Desktop\image1.jpg'

If(!(test-path $HTML_Path))
{
      write-host 'no'
}
else
{
rm $HTML_Path
}


